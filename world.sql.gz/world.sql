-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2020 at 11:04 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `world`
--

-- --------------------------------------------------------

--
-- Table structure for table `bangladesh`
--

CREATE TABLE `bangladesh` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(20) NOT NULL,
  `PEOPLE` int(11) NOT NULL,
  `TOURIST_PLACE` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bangladesh`
--

INSERT INTO `bangladesh` (`ID`, `NAME`, `PEOPLE`, `TOURIST_PLACE`) VALUES
(1, 'dhaka', 7422, 'saat Gombuj Jaame Masjid'),
(3, 'khulna', 6982, 'delta life tower'),
(4, 'rajshahi', 5632, 'Swaccho Tower'),
(6, 'rangpur', 7122, 'Red roof Inn Hotel');

-- --------------------------------------------------------

--
-- Table structure for table `brazil`
--

CREATE TABLE `brazil` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(20) NOT NULL,
  `PEOPLE` int(11) NOT NULL,
  `TPURIST_PLACE` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brazil`
--

INSERT INTO `brazil` (`ID`, `NAME`, `PEOPLE`, `TPURIST_PLACE`) VALUES
(1, 'Brasilia', 8500, 'catatinho'),
(2, 'Copacabana ', 85050, 'Copacabana Beach'),
(3, 'ipanema', 85050, 'ipanema Beach'),
(4, ' Safaris ', 8950, 'Horse Riding Safaris'),
(5, 'Iguazu ', 22560, 'Iguazu Falls');

-- --------------------------------------------------------

--
-- Table structure for table `india`
--

CREATE TABLE `india` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(20) NOT NULL,
  `PEOPLE` int(11) NOT NULL,
  `TOURIST_PLACE` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `india`
--

INSERT INTO `india` (`ID`, `NAME`, `PEOPLE`, `TOURIST_PLACE`) VALUES
(1, 'MUMBAI', 4500, 'JUHU'),
(2, 'PUNE', 3500, 'IMAGICA'),
(3, 'AMRAVATI', 2500, 'MALKHED'),
(4, 'NAGPUR', 5500, 'FUN-N-FOOD'),
(5, 'AURANGABAD', 6500, 'PROZON-MALL'),
(6, 'HYDRABAD', 8500, 'RAMOJI-FILM-CITY');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bangladesh`
--
ALTER TABLE `bangladesh`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `brazil`
--
ALTER TABLE `brazil`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `india`
--
ALTER TABLE `india`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
